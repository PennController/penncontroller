// To be implemented
class TooltipInstr extends Instruction {

}

PennController.instruction.tooltip = function(text){ return new TooltipInstr(text); };